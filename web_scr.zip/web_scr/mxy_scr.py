import re
import time
import logging

from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, ElementClickInterceptedException, TimeoutException, WebDriverException

logging.basicConfig(level=logging.INFO, format='%(asctime)s-%(processName)s-%(funcName)s-%(message)s')
logger = logging.getLogger(__name__)

number=0

class Video_Player():



    def add_number(self):
        self.number=self.number+1

    def __init__(self):
        self.create_browser()

    def create_browser(self):
        logger.info("启动了Firefox")
        self.browser=webdriver.Firefox()
        logger.info("打开了Firefox界面")
        url='https://passport.zhihuishu.com/login'
        self.browser.get(url)

        self.number=0
        logger.info('本次程序运行刷完了 '+str(self.number)+' 个视频')

        self.wait = WebDriverWait(self.browser, 10)
        logger.info('打开网页{0}'.format(url))

    def find_course(self):  #还没写完
        wait=WebDriverWait(self.browser,7)

        coursename=input('请输入课程名:')


    def new_list(self):
        all_videos = self.browser.find_elements_by_xpath('//li[contains(@class, "clearfix") and contains(@class, "video")]')
            #筛选出所有未完成视频
        self.videos = self.video_filter(all_videos)

        self.get_videos=self.get_video()

        logger.info('加载全部未完成节点')


    def video_init(self):
        input_id = self.browser.find_element_by_id('lUsername')#账号输入框
        input_pwd = self.browser.find_element_by_id('lPassword')#密码输入框
        logger.info('设定单击事件节点')

        #登陆
        enter_btn = self.browser.find_element_by_css_selector('.wall-sub-btn')#登陆按键
        input_id.send_keys('')#填入账号
        input_pwd.send_keys('')#填入密码
        enter_btn.click()

        wait=input('请在这里等一下,当网课视频开始播放后，在此输入回车启动程序')

        self.new_list()


        #四大事件关闭处理
    def dialog_test(self):
        '''弹框题目处理事件'''
        #/symbol/path[1]  默认A选项 
        try:
            dialog_text = self.browser.find_element_by_xpath('//div[contains(@class, "dialog-test")]')
            #获得所有选项
            items = dialog_text.find_elements_by_css_selector('.topic-item')
            logger.info('弹框题目处理事件，找到节点.dialog-test')
            item=items[0]
            item.click()
            logger.info('已勾选')
            btn = dialog_text.find_element_by_css_selector('.btn')
            btn.click()
            logger.info('关闭答题框')
        except:
            return False


    def dialog_time(self):
        '''超前学习弹窗处理事件'''
        try:
            #获得超前学习弹窗事件
            dialog = self.browser.find_element_by_xpath('//div[contains(@class, "dialog-look-habit")]')
            #获得关闭弹窗按键 
            btn = dialog.find_element_by_css_selector('.el-dialog__headerbtn')
            #单击关闭
            btn.click()

            logger.info('超前学习弹窗处理事件，找到节点.dialog-look-habit，关闭弹窗')
            return True
        except Exception:
            #未找到直接跳过
            return False


    def dialog_warning(self):
        '''学习警告弹窗事件'''
        try:
            #获得学习警告弹窗事件并获得关闭按键
            warning = self.browser.find_element_by_xpath('//div[contains(@class, "dialog-warn")]//button[@class="el-dialog__headerbtn"]')
            #单击关闭
            warning.click()
            logger.info('学习警告处理事件，找到节点.dialog-warn')

            return True
        except Exception:
            #未找到直接跳过
            pass


    def dialog_reading(self):
        '''学前必读弹窗事件'''
        try:
            #获得学习必读弹窗事件
            dialog_read = self.browser.find_element_by_xpath('/html/body/div[1]/div/div[7]/div[2]/div[1]/i')
            #单击关闭
            dialog_read.click()
            logger.info('学前必读处理事件，找到节点.dialog')

            return True
        except Exception:
            #未找到跳过
            pass
    def paused_handler(self):
        '''处理视频暂停事件'''
        wait = WebDriverWait(self.browser, 1)
        try:
            point = 'vjs-paused'
            #检查视频是否被暂停
            video_panel = self.browser.find_element_by_xpath('//div[contains(@class, "{0}")]'.format(point))
            if video_panel:
                #单击播放
                video_panel.click()
                logger.info('发现节点{0}, 转换'.format(point))
                wait.until(EC.staleness_of(video_panel))

        except Exception:
            pass

    def get_video(self):
    	#'''获得所有播放视频的生成器'''
        for video in self.videos:
            yield video


    def video_finish(self):
        '''视频完成处理事件'''

        try:
            current_time=self.browser.find_element_by_xpath('//*[@id="vjs_container"]/div[10]/div[4]/span[1]').get_attribute('textContent')
            total_time=self.browser.find_element_by_xpath('//*[@id="vjs_container"]/div[10]/div[4]/span[2]').get_attribute('textContent')
            if current_time[3:5]==total_time[3:5] :
                logger.info('这里抓取到了时间')
                self.add_number()
                logger.info('本次程序运行刷完了 '+str(self.number)+' 个视频')
                logger.info('可以点击下一集')
                self.new_list()
                s=self.videos[0]
                logger.info(s)
                s.click()
                logger.info('实现一次对下一节点的点击')
                time.sleep(6)
                # #流畅
                self.browser.execute_script('document.querySelector("#vjs_container > div.controlsBar > div.definiBox > div > b.line1bq.switchLine").click()')# 流畅
                logger.info('完成了流畅选择')
                time.sleep(2)
                self.browser.execute_script('document.querySelector("#vjs_container > div.controlsBar > div.speedBox > div > div.speedTab.speedTab15").click()')#1.5倍  
                logger.info('完成了1.5倍选择')

        except:
            pass


    def video_filter(self, videos):
        '''筛选掉所有观看完成视频'''
        new_video = []
        for video in videos:
            try:
                #视频已完成直接跳过
                finish = video.find_element_by_css_selector('.time_icofinish')
            except Exception:
                #未完成的视频放到未完成的列表中
                new_video.append(video)
        return new_video

if __name__=='__main__':
    player =Video_Player()
    player.video_init()
    while True:
        time.sleep(3)
        player.dialog_test()
        player.dialog_time()
        player.dialog_reading()
        player.dialog_warning()
        player.paused_handler()
        player.video_finish()
